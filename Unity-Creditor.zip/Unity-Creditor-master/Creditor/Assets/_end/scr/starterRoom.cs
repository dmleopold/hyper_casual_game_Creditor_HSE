﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AwakeerRoom : MonoBehaviour
{
    /*void Awake()
    {
        NextVisiter.Instance.AwakeCopy();
        RulesScript.Instance.AwakeCopy();
    }*/

}
